//
// Created by Administrator on 2025/3/29.
//

#include "Queue.h"

template<typename T>
Queue<T>::~Queue() {
    clear();
}

template<typename T>
void Queue<T>::push(T new_value) {
    std::lock_guard<std::mutex> lk(mt);
    if (work) {
        q.push(new_value);
        cv.notify_one();
    } else {
        if (releaseCallback) {
            releaseCallback(&new_value);
        }
    }
}

template<typename T>
int Queue<T>::pop(T& value) {
    std::unique_lock<std::mutex> lk(mt);
    cv.wait(lk, [this]{ return !work || !q.empty(); });
    if (!q.empty()) {
        value = q.front();
        q.pop();
        return 1;
    }
    return 0;
}

template<typename T>
void Queue<T>::setWork(int work) {
    std::lock_guard<std::mutex> lk(mt);
    this->work = work;
    cv.notify_all();
}

template<typename T>
int Queue<T>::empty() {
    std::lock_guard<std::mutex> lk(mt);
    return q.empty();
}

template<typename T>
int Queue<T>::size() {
    std::lock_guard<std::mutex> lk(mt);
    return q.size();
}

template<typename T>
void Queue<T>::clear() {
    std::lock_guard<std::mutex> lk(mt);
    while (!q.empty()) {
        T value = q.front();
        if (releaseCallback) {
            releaseCallback(&value);
        }
        q.pop();
    }
}

template<typename T>
void Queue<T>::setReleaseCallback(ReleaseCallback r) {
    std::lock_guard<std::mutex> lk(mt);
    releaseCallback = r;
}
