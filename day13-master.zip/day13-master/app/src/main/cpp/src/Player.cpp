//
// Created by Administrator on 2025/3/29.
//
#include <cstring>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

extern "C"
{
#include <libavutil/time.h>
}

#include "Log.h"
#include "Player.h"

void *play(void *args) {
    Player *player = static_cast<Player *>(args);
    // 主线程解复用
    player->demux();
    return 0;
}

Player::Player(const char *dataSource) {
    this->dataSource = new char[strlen(dataSource) + 1];
    strcpy(this->dataSource, dataSource);
    duration = 0;
}

Player::~Player() {
    if (formatContext) {
        avformat_close_input(&formatContext);
        formatContext = nullptr;
    }
    if (videoChannel) {
        delete videoChannel;
        videoChannel = nullptr;
    }
    if (videoRender) {
        delete videoRender;
        videoRender = nullptr;
    }
    if (dataSource) {
        delete[] dataSource;
        dataSource = nullptr;
    }
}

void Player::prepare() {
    formatContext = avformat_alloc_context();
    AVDictionary *options = 0;
    // 超时时间3秒
    av_dict_set(&options, "timeout", "3000000", 0);
    int ret = avformat_open_input(&formatContext, dataSource, 0, &options);
    av_dict_free(&options);
    if (ret != 0) {
        LOGE("avformat_open_input failed:%s", av_err2str(ret));
        return;
    }
    ret = avformat_find_stream_info(formatContext, 0);
    if (ret < 0) {
        LOGE("avformat_find_stream_info failed:%s", av_err2str(ret));
        return;
    }
    duration = formatContext->duration * 1.0 / 1000000;
    LOGI("duration:%f\n", duration);
    if (duration <= 0) {
        duration = 0;
    }

    int video_stream_index = -1;
    int audio_stream_index = -1;

    for (int i = 0; i < formatContext->nb_streams; ++i) {
        AVStream *stream = formatContext->streams[i];
        AVCodecParameters *codecpar = stream->codecpar;

        // Skip unsupported codec types
        if (codecpar->codec_type != AVMEDIA_TYPE_VIDEO &&
            codecpar->codec_type != AVMEDIA_TYPE_AUDIO) {
            continue;
        }

        AVCodec *dec = avcodec_find_decoder(codecpar->codec_id);
        if (!dec) {
            LOGE("Unsupported codec: %s (id=%d)",
                 avcodec_get_name(codecpar->codec_id),
                 codecpar->codec_id);
            continue;  // Skip this stream instead of failing
        }
        // 获得解码器上下文
        AVCodecContext *context = avcodec_alloc_context3(dec);
        if (context == NULL) {
            LOGE("avcodec_alloc_context3 failed:%s", av_err2str(ret));
            return;
        }
        ret = avcodec_parameters_to_context(context, codecpar);
        if (ret < 0) {
            LOGE("avcodec_parameters_to_context failed:%s", av_err2str(ret));
            return;
        }
        // 打开解码器
        ret = avcodec_open2(context, dec, 0);
        if (ret < 0) {
            LOGE("avcodec_parameters_to_context failed:%s", av_err2str(ret));
            return;
        }
        AVRational time_base = stream->time_base;
        if (codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            video_stream_index = i;
            AVStream *video_stream = formatContext->streams[video_stream_index];
            videoChannel = new VideoChannel(video_stream_index, context, video_stream->time_base,
                                            av_q2d(video_stream->avg_frame_rate));
            // FIXME: 第一帧初始化
            if (video_stream_index == 0) {
                LOGE("time_base:%d", time_base.num);
                width = context->width;
                height = context->height;
                if (videoRender->init(width, height)) {
                    LOGE("Could not set buffers geometry");
                    videoRender->release();
                }
            }
        } else if (codecpar->codec_type == AVMEDIA_TYPE_AUDIO) {
            audio_stream_index = i;
//            AVStream *audio_stream = formatContext->streams[audio_stream_index];
        }
    }
    if (video_stream_index == -1) {
        LOGE("Could not find video stream\n");
    }
    if (audio_stream_index == -1) {
        LOGE("Could not find audio stream\n");
    }
    if (video_stream_index == -1) {
        LOGE("video_stream_index == -1");
    }
    if (audio_stream_index == -1) {
        LOGE("audio_stream_index == -1");
    }
    double duration = formatContext->duration / (double) AV_TIME_BASE;
    LOGD("视频时间： %f\n", duration);
    if (duration <= 0) {
        LOGE("duration <= 0");
    }
}

void Player::start() {
    if (isPlaying) {
        return;
    }
    isPlaying = 1;
    if (videoChannel) {
        videoChannel->play();
    }
    pthread_create(&pid_play, NULL, play, this);
}

void Player::setRenderFrameCallback(RenderFrameCallback callback) {
    this->callback = callback;
}