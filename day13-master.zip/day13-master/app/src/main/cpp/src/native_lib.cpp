#include <jni.h>
#include "convert.h"
#include "Log.h"
#include <jni.h>
#include <string>
#include "Log.h"
#include <android/native_window.h>
#include "ANWRender.h"
#include "Player.h"
ANWRender *render;
Player *player = 0;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

void toRender(uint8_t *data) {
    pthread_mutex_lock(&mtx);
    player->videoRender->render(data);
    pthread_mutex_unlock(&mtx);
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_example_Player_nativePlay(JNIEnv *env, jobject instance, jstring dataSource_,
                                                 jobject surface) {
    const char *dataSource = env->GetStringUTFChars(dataSource_, 0);
    LOGI("dataSource %s\n", dataSource);

    player = new Player(dataSource);
//    player->videoRender = new ANWRender(ANativeWindow_fromSurface(env, surface));
//    player->setRenderFrameCallback(toRender);
    player->prepare();
    env->ReleaseStringUTFChars(dataSource_, dataSource);

    LOGI("prepare success\n");
    player->start();
    return 0;
}

extern "C"
JNIEXPORT jdouble JNICALL
Java_com_example_Player_nativeGetDuration(JNIEnv *env, jobject instance) {
    LOGD("get_time_Duration: %f\n", player->getDuration());
    return player->getDuration();
}


extern "C"
JNIEXPORT int JNICALL
Java_com_example_Player_nativeStop(JNIEnv *env, jobject instance) {
    if (player) {
        player->stop();
        player = 0;
    }

    return 0;
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_example_Player_nativeSeek(JNIEnv *env, jobject instance,
                                                 jdouble abs_position) {
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_Player_nativePause(JNIEnv *env, jobject instance, jboolean p) {
}

extern "C"
JNIEXPORT jdouble JNICALL
Java_com_example_Player_nativeGetPosition(JNIEnv *env, jobject thiz) {
    return 0;
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_Player_nativeSetSpeed(JNIEnv *env, jobject thiz, jfloat speed) {
    return 0;
}