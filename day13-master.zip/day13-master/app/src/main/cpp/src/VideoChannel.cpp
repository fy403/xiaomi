extern "C"
{
#include "libavutil/imgutils.h"
#include "libavutil/time.h"
#include "libavcodec/avcodec.h"
}
#include "VideoChannel.h"
#include "Log.h"
#include "Queue.h"

void *decode_task(void *args) {
    VideoChannel *channel = static_cast<VideoChannel *>(args);
    channel->decode();
    return 0;
}

VideoChannel::VideoChannel(int id, AVCodecContext *avCodecContext,
                           AVRational time_base, int fps)
        : BaseChannel(id, avCodecContext, time_base) {

    this->fps = fps;
    converter = new Converter("/sdcard/Download/output.yuv"); // 创建转换器实例
}

VideoChannel::~VideoChannel() {
    delete converter; // 释放转换器实例
}

void VideoChannel::play() {
    startWork();
    isPlaying = 1;
    // 解码
    pthread_create(&pid_decode, 0, decode_task, this);
}

// 解码
void VideoChannel::decode() {
    AVPacket *packet = 0;
    while (isPlaying) {
        int ret = packets.pop(packet);
        if (!isPlaying) {
            break;
        }
        // 取出失败
        if (!ret) {
            continue;
        }
        // 把包丢给解码器
        ret = avcodec_send_packet(avCodecContext, packet);
        releaseAvPacket(&packet);
        if (ret == AVERROR(EAGAIN)) {
            continue;
        } else if (ret < 0) {
            // 失败
            break;
        }
        AVFrame *frame = av_frame_alloc();
        ret = avcodec_receive_frame(avCodecContext, frame);
        if (ret == AVERROR(EAGAIN)) {
            continue;
        } else if (ret < 0) {
            break;
        }
        while (frames.size() > 100 && isPlaying) {
            av_usleep(1000 * 10);
            continue;
        }
        // 转换为YUV格式
        bool res = converter->convertAndStoreFrame(frame);
        if (!res){
            LOGE("转换错误");
            return;
        }
        av_frame_free(&frame);
    }
    releaseAvPacket(&packet);
}

void VideoChannel::pause() {
    isPause = 1;
}

void VideoChannel::resume() {
    isPause = 0;
}

void VideoChannel::stop() {
    isPlaying = 0;
    frames.setWork(0);
    packets.setWork(0);
    pthread_join(pid_decode, 0);
    pthread_join(pid_render, 0);
}