//
// Created by Administrator on 2025/3/29.
//

#ifndef PLAYER_H
#define PLAYER_H
#include "VideoChannel.h"
#include "ANWRender.h"

extern "C"
{
#include "libavformat/avformat.h"
}

class Player {
public:
    Player(const char *dataSource);

    ~Player();

    void prepare();

    void start();

    void demux();

    void stop();


    double getDuration() {
        return duration;
    }

public:
    char *dataSource;
    pthread_t pid;
    pthread_t pid_play = 0;
    pthread_t pid_stop = 0;

    AVFormatContext *formatContext = 0;
    VideoChannel *videoChannel = 0;
    bool isPlaying = 0;
    double duration = 0;
    ANWRender *videoRender = 0;
    int width;
    int height;
};
#endif //PLAYER_H
