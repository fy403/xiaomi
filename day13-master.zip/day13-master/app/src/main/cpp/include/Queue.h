//
// Created by Administrator on 2025/3/29.
//

#ifndef QUEUE_H
#define QUEUE_H
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>

template<typename T>
class Queue {
    using ReleaseCallback = std::function<void(T*)>;

public:
    Queue();
    ~Queue();

    void push(T new_value);
    int pop(T& value);
    void setWork(int work);
    int empty();
    int size();
    void clear();
    void setReleaseCallback(ReleaseCallback r);

private:
    std::mutex mt;
    std::condition_variable cv;
    std::queue<T> q;
    int work;
    ReleaseCallback releaseCallback;
};

#endif //QUEUE_H
