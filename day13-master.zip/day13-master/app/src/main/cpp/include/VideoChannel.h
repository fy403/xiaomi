#ifndef VIDEOCHANNEL_H
#define VIDEOCHANNEL_H


#include "BaseChannel.h"
#include "convert.h"

extern "C" {
#include "libswscale/swscale.h"
};


typedef void (*RenderFrameCallback)(uint8_t *);

class VideoChannel : public BaseChannel {
public:
    VideoChannel(int id, AVCodecContext *avCodecContext, AVRational time_base, int fps);

    ~VideoChannel();

    void play();

    void pause();

    void resume();

    void stop();

    void decode();

    Converter* converter;
private:
    pthread_t pid_decode;
    pthread_t pid_render;
    int fps;
};


#endif // VIDEOCHANNEL_H
