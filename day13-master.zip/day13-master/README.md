# day13 TASK
## 任务
### 1. 任务内容
![alt text](image-1.png)

- [x] `已完成任务`

> [点击进入src/cpp/src](./app/src/main/cpp/src)

### 实现整体流程说明
1. 用户调用Play JNI函数，传入视频文件路径。
2. 原生CPP创建并初始化一个Player类（控制整体流程）。Player进行准备工作，主要是定位视频流，并获取对应的解码器上下文。
3. Player准备工作后，开始创建解码器线程和解复用线程。
4. 解复用线程从格式上下文中读取package数据，送入到packages队列中。
5. 解码器线程从packages队列中读取package数据，解码出frame数据，进行转换操作。
6. 转换结束后写入文件，并回收资源。

#### 文档说明：

#### 0. 项目工程目录介绍。
```shell
├───3rd_party # 存放第三方库文件
│   └───ffmpeg
│       ├───libavcodec
│       ├───libavdevice
│       ├───libavfilter
│       ├───libavformat
│       ├───libavutil
│       ├───libswresample
│       └───libswscale
├───include # 项目头文件
└───src # 项目源码
```

#### 交叉编译ffmpeg，并将其转换为一个.so 文件。
```shell
#!/bin/bash  

# NDK path - consider updating to a newer version  
NDK=/usr/local/android-ndk-r29-beta1  
ARCH=aarch64  
API=29  
OUTPUT=$(pwd)/android/arm64-v8a  
LIBS=("libavcodec.so" "libavfilter.so" "libavformat.so" "libavutil.so" "libswresample.so" "libswscale.so")  
OUTPUT_LIB="libffmpeg.so"  

# Create output directory  
mkdir -p $OUTPUT  

# Toolchain path  
TOOLCHAIN=$NDK/toolchains/llvm/prebuilt/linux-x86_64  

# Verify NDK exists  
if [ ! -d "$NDK" ]; then  
  echo "NDK not found at $NDK"  
  exit 1  
fi  

build() {  
  ./configure \
  --target-os=android \
  --prefix=$OUTPUT \
  --arch=$ARCH \
  --sysroot=$TOOLCHAIN/sysroot \
  --disable-static \
  --disable-ffmpeg \
  --disable-ffplay \
  --disable-ffprobe \
  --disable-debug \
  --disable-doc \
  --disable-avdevice \
  --enable-shared \
  --enable-cross-compile \
  --cross-prefix=$TOOLCHAIN/bin/llvm- \
  --cc=$TOOLCHAIN/bin/aarch64-linux-android$API-clang \
  --cxx=$TOOLCHAIN/bin/aarch64-linux-android$API-clang++ \
  --nm=$TOOLCHAIN/bin/llvm-nm \
  --extra-cflags="-fpic"  

  make clean all  
  make -j12  
  make install  

  echo "Creating $OUTPUT_LIB with the following libraries:"  
  for LIB in "${LIBS[@]}"; do  
    echo "- $LIB"  
  done  

  cd $OUTPUT  

  ${TOOLCHAIN}/bin/aarch64-linux-android$API-clang -shared -o $OUTPUT_LIB "${LIBS[@]}"  

  if [ $? -eq 0 ]; then  
      echo "Successfully created $OUTPUT_LIB"  
  else  
      echo "Failed to create $OUTPUT_LIB"  
  fi  
}  

build  
```
![alt text](image.png)

#### 定义JNI接口
```cpp
extern "C"
JNIEXPORT jint JNICALL
Java_com_example_Player_nativePlay(JNIEnv *env, jobject instance, jstring dataSource_,
                                                 jobject surface) {
    const char *dataSource = env->GetStringUTFChars(dataSource_, 0);
    LOGI("dataSource %s\n", dataSource);

    player = new Player(dataSource); # 创建播放器对象
    player->prepare(); # 获取解码器上下文  AVFormatContext，以及创建初始化VideoChannel。
    env->ReleaseStringUTFChars(dataSource_, dataSource);

    LOGI("prepare success\n");
    player->start(); # 创建解码器线程。
    return 0;
}
```

#### 定义线程安全队列, 支持清理操作：方便后续Seek。
```cpp
#ifndef QUEUE_H
#define QUEUE_H
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>

template<typename T>
class Queue {
    using ReleaseCallback = std::function<void(T*)>;

public:
    Queue();
    ~Queue();

    void push(T new_value);
    int pop(T& value);
    void setWork(int work);
    int empty();
    int size();
    void clear();
    void setReleaseCallback(ReleaseCallback r);

private:
    std::mutex mt;
    std::condition_variable cv;
    std::queue<T> q;
    int work;
    ReleaseCallback releaseCallback;
};

#endif //QUEUE_H

```

#### 定义转换类Convert，初始化时读取配置文件，逐帧转换后存储转换后的数据。
```cpp
#include "convert.h"
#include "Log.h"
#include <fstream>
#include <string>

Converter::Converter(const std::string &output_path) : sws_ctx(nullptr) {
    // 打开输出文件
    output_file.open(output_path, std::ios::binary);
    if (!output_file.is_open()) {
        LOGE("Could not open output file: %s", output_path.c_str());
        throw std::runtime_error("Failed to open output file");
    }
}

Converter::~Converter() {
    // 释放资源并关闭文件
    if (sws_ctx) {
        sws_freeContext(sws_ctx);
        sws_ctx = nullptr;
    }
    if (output_file.is_open()) {
        output_file.close();
    }
}

bool Converter::convertAndStoreFrame(AVFrame *frame) {
    if (!frame) {
        LOGE("Invalid input parameters");
        return false;
    }

    int width = frame->width;
    int height = frame->height;

    // 转换为YUV420P格式
    AVFrame *frame_yuv420p = av_frame_alloc();
    if (!frame_yuv420p) {
        LOGE("Failed to allocate AVFrame");
        return false;
    }

    frame_yuv420p->format = AV_PIX_FMT_YUV420P;
    frame_yuv420p->width = width;
    frame_yuv420p->height = height;

    int ret = av_image_alloc(frame_yuv420p->data, frame_yuv420p->linesize,
                             width, height, AV_PIX_FMT_YUV420P, 32);
    if (ret < 0) {
        LOGE("Could not allocate raw picture buffer");
        av_frame_free(&frame_yuv420p);
        return false;
    }

    sws_ctx = sws_getContext(
            frame->width, frame->height, (AVPixelFormat)frame->format,
            frame->width, frame->height, AV_PIX_FMT_YUV420P,
            SWS_BILINEAR, nullptr, nullptr, nullptr);

    if (!sws_ctx) {
        LOGE("Failed to create SwsContext");
        av_frame_free(&frame_yuv420p);
        return false;
    }

    sws_scale(sws_ctx, (const uint8_t *const *)frame->data, frame->linesize,
              0, frame->height, frame_yuv420p->data, frame_yuv420p->linesize);

    // 写入Y分量(亮度)
    for (int y = 0; y < frame_yuv420p->height; y++) {
        output_file.write(reinterpret_cast<char*>(frame_yuv420p->data[0] + y * frame_yuv420p->linesize[0]), width);
    }

    // 写入U分量(色度)
    for (int y = 0; y < frame_yuv420p->height / 2; y++) {
        output_file.write(reinterpret_cast<char*>(frame_yuv420p->data[1] + y * frame_yuv420p->linesize[1]), width / 2);
    }

    // 写入V分量(色度)
    for (int y = 0; y < frame_yuv420p->height / 2; y++) {
        output_file.write(reinterpret_cast<char*>(frame_yuv420p->data[2] + y * frame_yuv420p->linesize[2]), width / 2);
    }

    // 释放资源
    sws_freeContext(sws_ctx);
    sws_ctx = nullptr;
    av_frame_free(&frame_yuv420p);

    return true;
}
```

#### 实现Player类，控制播放流程
> 启动时先进行初始化操作，初始化完毕后，创建解码器线程。
```cpp
//
// Created by Administrator on 2025/3/29.
//

#ifndef PLAYER_H
#define PLAYER_H
#include "VideoChannel.h"
#include "ANWRender.h"

extern "C"
{
#include "libavformat/avformat.h"
}

class Player {
public:
    Player(const char *dataSource);

    ~Player();

    void prepare();

    void start();

    void demux();

    void stop();


    double getDuration() {
        return duration;
    }

public:
    char *dataSource;
    pthread_t pid;
    pthread_t pid_play = 0;
    pthread_t pid_stop = 0;

    AVFormatContext *formatContext = 0; # 保存格式上下文，方便后续解码使用
    VideoChannel *videoChannel = 0; # 定义一个视频解码类
    bool isPlaying = 0;
    double duration = 0;
    ANWRender *videoRender = 0;
    int width;
    int height;
};
#endif //PLAYER_H
```

#### 定义解复用函数，读取视频流package送入到VideChannel的packages队列。
```cpp
#include "Player.h"
extern "C"
{
#include <libavutil/time.h>
}

// 解复用器
void Player::demux() {
    int ret = 0;
    while (isPlaying) {
        // 数据大小太大或者数量太多->睡眠优化
        if (videoChannel && videoChannel->packets.size() > 100) {
            av_usleep(1000 * 10);
            continue;
        }

        AVPacket *packet = av_packet_alloc();
        ret = av_read_frame(formatContext, packet);
        if (ret == 0) {
            if (videoChannel && packet->stream_index == videoChannel->id) {
                videoChannel->packets.push(packet);
            }
        } else if (ret == AVERROR_EOF) {
            if (videoChannel->packets.empty() && videoChannel->frames.empty()) {
                break;
            }
        } else {
            return;
        }
    }
    isPlaying = 0;
    videoChannel->stop();
};
```
#### 解码器线程函数局部定义: 读取packages队列的数据并送入解码器，解码后送入转换器。
```c++

// 解码
void VideoChannel::decode() {
    AVPacket *packet = 0;
    while (isPlaying) {
        int ret = packets.pop(packet);
        if (!isPlaying) {
            break;
        }
        // 取出失败
        if (!ret) {
            continue;
        }
        // 把包丢给解码器
        ret = avcodec_send_packet(avCodecContext, packet);
        releaseAvPacket(&packet);
        if (ret == AVERROR(EAGAIN)) {
            continue;
        } else if (ret < 0) {
            // 失败
            break;
        }
        AVFrame *frame = av_frame_alloc();
        ret = avcodec_receive_frame(avCodecContext, frame);
        if (ret == AVERROR(EAGAIN)) {
            continue;
        } else if (ret < 0) {
            break;
        }
        while (frames.size() > 100 && isPlaying) {
            av_usleep(1000 * 10);
            continue;
        }
        // 转换为YUV格式
        bool res = converter->convertAndStoreFrame(frame);
        if (!res){
            LOGE("转换错误");
            return;
        }
        av_frame_free(&frame);
    }
    releaseAvPacket(&packet);
}
```

#### 4. 最终结果
![alt text](1.gif)
![alt result2](2.gif)