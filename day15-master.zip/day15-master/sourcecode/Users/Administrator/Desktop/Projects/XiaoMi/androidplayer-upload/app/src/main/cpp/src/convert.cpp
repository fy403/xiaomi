
void Convert::writeHeader(std::ofstream &output_file_stream, int width, int height) {
    output_file_stream.write(reinterpret_cast<char *>(&width), sizeof(width));
    output_file_stream.write(reinterpret_cast<char *>(&height), sizeof(height));
}

void Convert::writeFrameToOutputFile(AVFrame *frame_yuv420p, std::ofstream &output_file_stream) {
    for (int y = 0; y < frame_yuv420p->height; y++) {
        output_file_stream.write(reinterpret_cast<char *>(frame_yuv420p->data[0] + y * frame_yuv420p->linesize[0]),
                                 frame_yuv420p->width);
    }

    for (int y = 0; y < frame_yuv420p->height / 2; y++) {
        output_file_stream.write(reinterpret_cast<char *>(frame_yuv420p->data[1] + y * frame_yuv420p->linesize[1]),
                                 frame_yuv420p->width / 2);
    }

    for (int y = 0; y < frame_yuv420p->height / 2; y++) {
        output_file_stream.write(reinterpret_cast<char *>(frame_yuv420p->data[2] + y * frame_yuv420p->linesize[2]),
                                 frame_yuv420p->width / 2);
    }
}

int Convert::processVideoStream(JNIEnv *env, const char *input_filename, const char *output_filename) {
    if (avformat_open_input(&fmt_ctx, input_filename, nullptr, nullptr) != 0) {
        std::cerr << "Could not open input file" << std::endl;
        return -2;
    }

    if (avformat_find_stream_info(fmt_ctx, nullptr) < 0) {
        std::cerr << "Could not find stream information" << std::endl;
        avformat_close_input(&fmt_ctx);
        return -3;
    }

    int video_stream_index = -1;
    AVCodecParameters *codecpar = nullptr;
    for (unsigned int i = 0; i < fmt_ctx->nb_streams; i++) {
        if (fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            video_stream_index = i;
            codecpar = fmt_ctx->streams[i]->codecpar;
            break;
        }
    }

    if (video_stream_index == -1) {
        std::cerr << "Could not find video stream" << std::endl;
        avformat_close_input(&fmt_ctx);
        return -4;
    }

    AVCodec *codec = avcodec_find_decoder(codecpar->codec_id);
    if (!codec) {
        std::cerr << "Codec not found" << std::endl;
        avformat_close_input(&fmt_ctx);
        return -5;
    }

    dec_ctx = avcodec_alloc_context3(codec);
    if (!dec_ctx) {
        std::cerr << "Could not allocate video codec context" << std::endl;
        avformat_close_input(&fmt_ctx);
        return -6;
    }

    if (avcodec_parameters_to_context(dec_ctx, codecpar) < 0) {
        std::cerr << "Failed to copy codec parameters to decoder context" << std::endl;
        avcodec_free_context(&dec_ctx);
        avformat_close_input(&fmt_ctx);
        return -7;
    }

    if (avcodec_open2(dec_ctx, codec, nullptr) < 0) {
        std::cerr << "Failed to open codec for decoding" << std::endl;
        avcodec_free_context(&dec_ctx);
        avformat_close_input(&fmt_ctx);
        return -8;
    }

    frame = av_frame_alloc();
    frame_yuv420p = av_frame_alloc();
    if (!frame || !frame_yuv420p) {
        std::cerr << "Could not allocate video frame" << std::endl;
        av_frame_free(&frame);
        av_frame_free(&frame_yuv420p);
        avcodec_free_context(&dec_ctx);
        avformat_close_input(&fmt_ctx);
        return -8;
    }

    std::ofstream output_file_stream(output_filename, std::ios::binary);
    if (!output_file_stream.is_open()) {
        std::cerr << "Could not open output file" << std::endl;
        av_frame_free(&frame);
        av_frame_free(&frame_yuv420p);
        avcodec_free_context(&dec_ctx);
        avformat_close_input(&fmt_ctx);
        return -10;
    }

    // 写入宽度和高度信息
    writeHeader(output_file_stream, codecpar->width, codecpar->height);

    AVPacket pkt;
    int response = 0;
    while (av_read_frame(fmt_ctx, &pkt) >= 0) {
        if (pkt.stream_index == video_stream_index) {
            response = avcodec_send_packet(dec_ctx, &pkt);
            if (response < 0) {
                std::cerr << "Error sending a packet for decoding" << std::endl;
                break;
            }

            while (response >= 0) {
                response = avcodec_receive_frame(dec_ctx, frame);
                if (response == AVERROR(EAGAIN) || response == AVERROR_EOF) {
                    break;
                } else if (response < 0) {
                    std::cerr << "Error during decoding" << std::endl;
                    break;
                }

                handleFrame(frame, frame_yuv420p, output_file_stream);
            }
        }
        av_packet_unref(&pkt);
    }

    output_file_stream.close();
    releaseResources();

    return 0;
}
