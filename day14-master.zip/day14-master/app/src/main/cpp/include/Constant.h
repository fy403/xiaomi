#ifndef CONSTANT_H
#define CONSTANT_H
#define DELETE(obj) if(obj){ delete obj; obj = 0; }
#endif