#ifndef PLAYERCONTEXT_H
#define PLAYERCONTEXT_H

#include <atomic>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdio.h>
#include <thread>
#include "Clock.h"
#include  "Log.h"

extern "C"
{
#include "libavformat/avformat.h"
#include "libavutil/time.h"
#include "libavutil/rational.h"
}

class PlayerContext {
public:
    PlayerContext() = default;

    double audio_hw_delay = 0;
    Clock audio_clock_t;
    Clock video_clock_t;
    double video_duration = 0;
    AVRational video_base_time;
    AVRational audio_base_time;
    AVStream *video_stream = 0;
    AVStream *audio_stream = 0;

    void setClockAt(Clock &clock, double pts, double time) {
        clock.pts = pts;
        clock.last_updated = time;
    }

    void setClock(Clock &clock, double pts_plus) {
//        LOGD("clock: %fs\n", pts_plus);
        setClockAt(clock, pts_plus, (double) av_gettime() / AV_TIME_BASE);
    }

    double getAudioClock() const { return getClock(audio_clock_t); }

    double getVideoClock() const { return getClock(video_clock_t); }

    double getAudioRelaTime() const {
        return audio_clock_t.pts;
    }

    double getVideoRelaTime() const {
        return video_clock_t.pts;
    }

    double getClock(const Clock &c) const {
        double time = (double) av_gettime() / AV_TIME_BASE;
        return c.pts + time - c.last_updated;
    }
    ~PlayerContext() {
        delete video_stream;
        delete audio_stream;
        video_stream = 0;
        audio_stream = 0;
    }
};

#endif