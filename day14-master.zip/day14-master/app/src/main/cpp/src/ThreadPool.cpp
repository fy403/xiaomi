//
// Created by Administrator on 2025/3/30.
//
#include "ThreadPool.h"

int32_t GlobalThreadPool::corePoolSize = 2;
int32_t GlobalThreadPool::maximumPoolSize = 4;
int32_t GlobalThreadPool::queueCapacity=256;

ThreadPool::ThreadPool(size_t corePoolSize, size_t maximumPoolSize, size_t queueCapacity)
        : corePoolSize(corePoolSize),
          maximumPoolSize(maximumPoolSize),
          activeThreads(0),
          taskQueue(queueCapacity),
          isShutdown(false) {}

ThreadPool::~ThreadPool()
{
    shutdown();
}

int ThreadPool::submit(std::function<void()> task)
{
    if (isShutdown.load())
    {
        throw std::runtime_error("ThreadPool is shutdown");
    }

    if (activeThreads.load() < corePoolSize && addWorker(task))
    {
        return 0;
    }

    if (taskQueue.enqueue(task))
    {
        return 0;
    }

    if (activeThreads.load() < maximumPoolSize && addWorker(task))
    {
        return 0;
    }

    // std::cerr << "Task discarded: thread pool is full" << std::endl;
    return -1;
}

bool ThreadPool::addWorker(std::function<void()> task)
{
    std::lock_guard<std::mutex> lock(mtx);
    if (activeThreads.load() >= maximumPoolSize)
    {
        return false;
    }

    workers.emplace_back([this, task]
                         {
                             activeThreads.fetch_add(1);
                             if (task) {
                                 task();
                             }
                             workerThread(); });

    return true;
}

void ThreadPool::workerThread()
{
    while (!isShutdown.load())
    {
        std::function<void()> task;

        if (taskQueue.dequeue(task))
        {
            task();
        }
        else
        {
            std::lock_guard<std::mutex> lock(mtx);
            if (activeThreads.load() > corePoolSize)
            {
                activeThreads.fetch_sub(1);
                return;
            }
            std::this_thread::yield();
        }
    }
    activeThreads.fetch_sub(1);
}

void ThreadPool::shutdown()
{
    isShutdown.store(true);
    for (auto &worker : workers)
    {
        if (worker.joinable())
        {
            worker.join();
        }
    }
    workers.clear();
}
