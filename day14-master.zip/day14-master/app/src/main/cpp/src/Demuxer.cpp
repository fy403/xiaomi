#include "Player.h"
#include "Log.h"
extern "C"
{
#include <libavutil/time.h>
}

// 解复用器
void Player::demux() {
    LOGI("demux starting....");
    int ret = 0;
    while (isPlaying) {
        // 数据大小太大或者数量太多->睡眠优化
        if (videoChannel && videoChannel->packets.size() > 100) {
            av_usleep(1000 * 10);
            continue;
        }

        AVPacket *packet = av_packet_alloc();
        ret = av_read_frame(formatContext, packet);
        if (ret == 0) {
            if (videoChannel && packet->stream_index == videoChannel->id) {
                videoChannel->packets.push(packet);
            }
        } else if (ret == AVERROR_EOF) {
            if (videoChannel->packets.empty() && videoChannel->frames.empty()) {
                break;
            }
        } else {
            return;
        }
    }
    isPlaying = 0;
    videoChannel->stop();
}